import React from 'react'

import "./PopupComponent.css";
import Popup from "reactjs-popup";
import {
    SkeletonText,
  } from '@chakra-ui/react'
  import Stack from '@mui/material/Stack';
  import Box from '@mui/material/Box';
  import Button from '@mui/material/Button';
  import ButtonGroup from '@mui/material/Button';
  import { FaLocationArrow, FaTimes,FaPlus } from 'react-icons/fa'
  import Grid from '@mui/material/Grid'; 
import {
    useJsApiLoader,
    GoogleMap,
    Marker,
    Autocomplete,
    DirectionsRenderer,
  } from '@react-google-maps/api'
  import { useRef, useState } from 'react'
  
    const center = { lat: 48.8584, lng: 2.2945 }

    export default function AutoCompleteSearch() {

    const { isLoaded } = useJsApiLoader({
        googleMapsApiKey: 'AIzaSyDsY_3NvBPZxr3HJYrF41AFUZGbDRosKfY',
        libraries: ['places'],
      })
    
      const [map, setMap] = useState(/** @type google.maps.Map */ (null))
      const [directionsResponse, setDirectionsResponse] = useState(null)
      const [distance, setDistance] = useState('')
      const [duration, setDuration] = useState('')
      const [show,setShow]=useState(false)

      

      /** @type React.MutableRefObject<HTMLInputElement> */
      const originRef = useRef()
      /** @type React.MutableRefObject<HTMLInputElement> */
      const destiantionRef = useRef()
      if (!isLoaded) {
        return <SkeletonText />
      }
      async function calculateRoute() {
        if (originRef.current.value === '' || destiantionRef.current.value === '') {
          return
        }
        // eslint-disable-next-line no-undef
        const google = window.google;
        const directionsService = new google.maps.DirectionsService()
        const directionsRenderer = new google.maps.DirectionsRenderer()
        const waypts = [];
        const checkboxArray = document.getElementById("waypoints");
        for (let i = 0; i < checkboxArray.length; i++) {
          if (checkboxArray.options[i].selected) {
            waypts.push({
              location: checkboxArray[i].value,
              stopover: true,
            });
          }
        }

        

        const results = await directionsService.route({
          origin: originRef.current.value,
          destination: destiantionRef.current.value,
          waypoints: waypts,
          optimizeWaypoints: true,
          // eslint-disable-next-line no-undef
          travelMode: google.maps.TravelMode.DRIVING,
        })
        directionsRenderer.setDirections(results);

        const route = results.routes[0];
      const summaryPanel = document.getElementById("directions-panel");

      summaryPanel.innerHTML = "";

      // For each route, display summary information.
      for (let i = 0; i < route.legs.length; i++) {
        const routeSegment = i + 1;

        summaryPanel.innerHTML +=
          "<b>Route: " + routeSegment + "</b><br>";
        summaryPanel.innerHTML += route.legs[i].start_address + " to ";
        summaryPanel.innerHTML += route.legs[i].end_address + "<br>";
        summaryPanel.innerHTML += route.legs[i].distance.text + "<br><br>";

         setDirectionsResponse(results)
         setDistance(results.routes[0].legs[0].distance.text)
         setDuration(results.routes[0].legs[0].duration.text)
      
      }
      for (var i = 0; i < route.legs.length; i++) {
        computeTotalDistance(results);
        
      }

      function computeTotalDistance(result) {
        var totalDist = 0;
        var totalTime = 0;
        var myroute = result.routes[0];
        for (i = 0; i < myroute.legs.length; i++) {
          totalDist += myroute.legs[i].distance.value;
          totalTime += myroute.legs[i].duration.value;
        }
        totalDist = totalDist / 1000.
        document.getElementById("total").innerHTML = "<div class='text_bottom'>Total KM - " + totalDist + " km </div> <div class='text_bottom'>ETA - " + (totalTime / 60).toFixed(2) + " minutes </div> ";
      }
    }
    
    
      function clearRoute() {
        setDirectionsResponse(null)
        setDistance('')
        setDuration('')
        originRef.current.value = ''
        destiantionRef.current.value = ''
      }

      
        


  return (
    <>

<Popup trigger={<Button variant="contained" > Click to open modal </Button>} modal nested>
        {(close) => (
          <Stack direction={{ xl: 'column', sm: 'row' }} className="modal">
            <Stack Grid container  className="content">
              <Stack>
                <Stack className="close_btn">
                  <Button variant="contained" className="close" onClick={() => close()}>
                    &times;
                  </Button>
                </Stack>
                <Grid container spacing={2} direction={{ xl: 'row', sm: 'row' }} className="mid_sec">
                <Grid xs={12} xl={6} lg={6}>
                <Grid xs={12}  className="form_sec">
                <Box sx={{position:'relative', display:'flex', flexDirection:'column',width:'80%', alignItems:'center'}}>
    
      <Box sx={{padding:'4px', borderRadius:'4px', margin:'4px', bgcolor:'white',width:'100%', zIndex:'1'  }}>
        <Stack direction="column" justifyContent='space-between' width='100%' spacing={2}>

          <Box sx={{ flexGrow:'1'}}>
              <h3>Start Location</h3>
              <Autocomplete>
              <input className='input_field' type="text" placeholder='Origin'  ref={originRef} ></input>
              </Autocomplete>
              <Button variant="text" className='close_btn_form' aria-label='center back' endIcon={<FaTimes />} onClick={clearRoute}>
              </Button>
          </Box>
          
    
    
          <Box sx={{ flexGrow:'1'}}>
          <h3>Waypoints:</h3>
          {
       show?<Autocomplete>
       <input className='input_field' type="text" name="waypoints" autocomplete="on"></input>
       </Autocomplete>:null
     }
     {/* <button onClick={()=>setShow(true)} >Show</button>
     <button onClick={()=>setShow(false)} >Hide</button> */}
<button className='plus_icon' onClick={()=>setShow(!show)} >{<FaPlus />}</button> 



          <select multiple id="waypoints" className='w-full'>
            <option value="Hajipur">Hajipur</option>
            <option value="Bhagwanpur">Bhagwanpur</option>
            <option value="Kurhani">Kurhani</option>
            <option value="Sarai">Sarai</option>
            <option value="Goraul">Goraul</option>
          </select>

          <Autocomplete>
       <input  className='input_field' type="text" placeholder="WayPoints" name="waypoints[]" autocomplete="on"></input>
       </Autocomplete>
          </Box>

          <Box sx={{ flexGrow:'1'}}>
          <h3>End Location</h3>
            <Autocomplete>
               <input className='input_field' type="text" placeholder='Destination'  ref={destiantionRef}></input> 
            </Autocomplete>
          </Box>

          <ButtonGroup sx={{position:'relative', display:'flex', justifyContent:'space-between', alignItems:'center'}} > 
            <Button className='calculate_btn' variant="contained" type='submit' onClick={calculateRoute}>
              Calculate Route
            </Button>
          </ButtonGroup>

          <Box>
          <div id="directions-panel"></div>
          </Box>

        </Stack>
        <Stack spacing={2} mt={2} justifyContent='space-between'>

        <Stack id="total">


        </Stack>
          {/* <Stack className='text_bottom'>Total KM - <span>{distance} km</span></Stack>
          <Stack className='text_bottom'>ETA - <span>{duration}</span> </Stack>  */}
       
         
        </Stack>
      </Box>
    </Box>
    </Grid>
                  </Grid>
                  <Grid xs={12} xl={6} lg={6} className='overflow-hidden br-10'>
                  <Box sx={{position:'relative', borderRadius:'0px 10px 10px 0px', left:0, top:0, height:'100%', width:'100%'}} >
     {/* Google Map Box */}
     <GoogleMap
       center={center}
       zoom={15}
       mapContainerStyle={{ width: '100%', height: '100%' }}
       options={{
         zoomControl: false,
         streetViewControl: false,
         mapTypeControl: false,
         fullscreenControl: false,
       }}
       onLoad={map => setMap(map)}
     >
       <Marker position={center} />
       {directionsResponse && (
         <DirectionsRenderer directions={directionsResponse} />
       )}
     </GoogleMap>
   </Box>
   <Button className='check_btn' variant="contained" isRound color="secondary" aria-label='center back' endIcon={<FaLocationArrow />} onClick={() => {
    map.panTo(center)
   map.setZoom(15)
  }}></Button>
                  </Grid>
                </Grid>
              </Stack>
            </Stack>
          </Stack>
        )}
      </Popup>


      
     
 </>
  )
}
