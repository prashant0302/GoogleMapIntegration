import React from 'react'
import "./PopupComponent.css";
import Popup from 'reactjs-popup';

export default function PopupComponent() {
    return (
        <div>
            <Popup trigger=
                {<button> Click to open modal </button>}
                modal nested>
                {
                    close => (
                        <div className='modal'>
                            <div className='content'>
                                <div>
                                <div className='close_btn'>
                                <button class="close" onClick=
                                    {() => close()}>
                                       <span >&times;</span>
                                </button>
                                
                            </div>
                                <div className='mid_sec'>
                                
                            <div className='left_sec'></div>
                                <div className='right_sec'>
                               

                                </div>
                            </div>
                            
                                </div>
                                
                            
                                
                            </div>
                            
                        </div>
                    )
                }
            </Popup>
        </div>
    )
};
