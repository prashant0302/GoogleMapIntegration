import React from "react";

import AutoCompleteSearch from "./components/AutoCompleteSearch";
import Selectdestination from "./components/Selectdestination";

import PopupComponent from "./components/PopupComponent";

function App() {
  return (
    <>
      <AutoCompleteSearch />
    </>
  );
}

export default App;
