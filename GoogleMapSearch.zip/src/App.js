import React from "react";
import GoogleMapSearch from "./components/GoogleMapSearch"

function App() {
  return (
    <>
     <GoogleMapSearch/>
    </>
  );
}

export default App;
